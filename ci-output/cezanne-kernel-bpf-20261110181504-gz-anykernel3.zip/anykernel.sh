#!/sbin/sh
## AnyKernel3 Ramdisk Script
## osm0sis @ xda-developers

### AnyKernel properties
properties() { '
kernel.string=cezanne-bpf;
do.devicecheck=1;
do.modules=0;
do.systemless=1;
do.cleanup=1;
do.cleanuponabort=0;
device.name1=Redmi K30 Ultra;
device.name2=cezanne;
supported.versions=
supported.patchlevels=
'; }

### AnyKernel install
. /anykernel/tools;

. /anykernel/props;
command -v loky >/dev/null 2>&1 && . /loky.sh;
. /anykernel/ak3-core.sh;

## AnyKernel methods
. /anykernel/methods.sh;
. /anykernel/tools;

## AnyKernel file attributes
set_perm_recursive $ramdisk 0 0 755 644;

## AnyKernel install
dump_boot;
write_boot;
## end install
