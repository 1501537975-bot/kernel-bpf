#!/sbin/sh
patch_dtb() {
  if [ -f /kernel/Image.gz-dtb ]; then
    dd if=/kernel/Image.gz-dtb of=boot.img conv=notrunc
  fi
}
