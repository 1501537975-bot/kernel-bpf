#!/sbin/sh
## AnyKernel3 Core
## osm0sis @ xda-developers

ui_print() { echo "$1"; }

## boot dir function
dump_boot() {
  ui_print " Dumping boot..."
  mkdir -p /tmp/anykernel
  dd if=/dev/block/bootdevice/by-name/boot of=/tmp/anykernel/boot.img
}

## end boot function
write_boot() {
  ui_print " Writing boot..."
  cd /tmp/anykernel
  ui_print " Patching kernel..."
  dd if=/kernel/Image.gz of=boot.img conv=notrunc
  ui_print " Installing kernel..."
  dd if=boot.img of=/dev/block/bootdevice/by-name/boot
  ui_print " Done!"
}
